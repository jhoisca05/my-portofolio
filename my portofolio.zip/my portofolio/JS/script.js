const menuBtn = document.getElementById("menuBtn");
const navMenu = document.getElementById("navMenu");

menuBtn.addEventListener("click", () => {
  navMenu.classList.toggle("show");
});

document.querySelectorAll("#navMenu a").forEach(link => {
  link.addEventListener("click", () => {
    navMenu.classList.remove("show");
  });
});

/* Efek sederhana: foto muncul ketika section terlihat */
const items = document.querySelectorAll(
  ".photo-card, .polaroid, .note, .favorite-note, .education, .moments figure, .skills"
);

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

items.forEach(item => {
  item.style.opacity = "0";
  item.style.transform += " translateY(18px)";
  item.style.transition = "opacity .7s ease, transform .7s ease";
  observer.observe(item);
});

document.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    items.forEach(item => {
      if (item.getBoundingClientRect().top < window.innerHeight) {
        item.classList.add("visible");
      }
    });
  }, 100);
});

const style = document.createElement("style");
style.textContent = `
  .visible {
    opacity: 1 !important;
    transform: none !important;
  }
`;
document.head.appendChild(style);
